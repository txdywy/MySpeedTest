### HTTP 

This test checks if a given url is reachable or not.

### Description

* Do a HTTP GET request to the given url

### Result

* Request
    + hostname
    + path
* Result
    + status
    + headers
    + body
