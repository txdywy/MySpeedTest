### TCP Connect

This test checks if a given IP address is reachable using a TCP CONNECT call.

### Description

* Do a TCP Connect call to a given IP address

### Results

Stores the following information

* Request
  + IP
  + Port
* Result
  + True/False
