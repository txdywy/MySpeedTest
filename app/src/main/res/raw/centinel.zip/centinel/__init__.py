__title__ = 'centinel'
__version__ = '0.1.5.2'

from . import client, backend, daemonize
